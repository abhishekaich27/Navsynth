
1. To run this implementation, please download the Chair-CAD dataset 'https://www.di.ens.fr/willow/research/seeing3Dchairs/data/rendered_chairs.tar'.

2. Create a conda environment with the 'environment.yml', and set the path to the dataset downloaded in Step 1.

3. Then run 'python class_gen.py'
